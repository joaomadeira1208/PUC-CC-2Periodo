# Aviso da entrega do Guia 10 na pasta atual.

Professor Theldo, gostaria de informa-lo que nessa pasta estou enviando o Guia 10, a pasta "Guia_10" contém a pasta "800854-Joao_Madeira_Freitas" referente do Guia 10.

Atenciosamente, João Madeira.