# Aviso da entrega do Guia 12 no zip atual.

Professor Theldo, gostaria de informa-lo que nessa pasta estou enviando o Guia 12, a pasta "Guia_12" contém a pasta "800854-Joao_Madeira_Freitas" referente do Guia 12. E a pasta "Guia_13" contém a pasta "800854-Joao_Madeira_Freitas" referente ao Guia 13.

Atenciosamente, João Madeira.