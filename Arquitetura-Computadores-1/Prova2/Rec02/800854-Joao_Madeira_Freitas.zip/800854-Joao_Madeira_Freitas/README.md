# Explicação do envio.

Professor Theldo, gostaria de informa-lo que nessa pasta estou enviando a atividade completa. No arquivo txt as questões de número 1 a 3 estão feitas e nas respectivas pastas Questao04 e Questao05 está presente os arquivos de cada exercício.

Atenciosamente, João Madeira.